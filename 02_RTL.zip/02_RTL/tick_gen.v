`timescale 1ns/1ps
module tick_gen #(
    parameter integer CLK_FREQ_HZ = 50000000
)(
    input wire clk,
    input wire rst_n,
    output reg tick_1s
);
    reg [31:0] count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            count   <= 32'd0;
            tick_1s <= 1'b0;
        end
        else if (count == CLK_FREQ_HZ - 1) begin
            count   <= 32'd0;
            tick_1s <= 1'b1;
        end
        else begin
            count   <= count + 1'b1;
            tick_1s <= 1'b0;
        end
    end
endmodule
