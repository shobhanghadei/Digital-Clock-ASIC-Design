`timescale 1ns/1ps
module tb_minutes_counter;
    reg clk, rst_n, min_tick;
    wire [5:0] min_count;
    wire hour_tick;
    integer i;

    minutes_counter DUT (
        .clk(clk), .rst_n(rst_n), .min_tick(min_tick),
        .min_count(min_count), .hour_tick(hour_tick)
    );

    always #5 clk = ~clk;

    task send_tick;
    begin
        @(negedge clk);
        min_tick = 1'b1;
        @(negedge clk);
        min_tick = 1'b0;
        #1;
    end
    endtask

    initial begin
        clk = 0; rst_n = 0; min_tick = 0;
        $dumpfile("minutes_counter.vcd");
        $dumpvars(0, tb_minutes_counter);
        #12; rst_n = 1;

        for (i = 0; i < 59; i = i + 1)
            send_tick;

        if (min_count == 6'd59)
            $display("PASS: Minutes reached 59");
        else
            $display("FAIL: Minutes count incorrect");

        send_tick;
        if (min_count == 6'd0 && hour_tick == 1'b1)
            $display("PASS: Minutes rollover and hour tick");
        else
            $display("FAIL: Minutes rollover");
        $finish;
    end
endmodule
