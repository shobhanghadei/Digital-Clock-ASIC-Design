`timescale 1ns/1ps
module tb_digital_clock_top;
    reg clk;
    reg rst_n;
    wire [3:0] hour_tens, hour_ones;
    wire [3:0] min_tens, min_ones;
    wire [3:0] sec_tens, sec_ones;
    integer errors;

    digital_clock_top #(.CLK_FREQ_HZ(2)) DUT (
        .clk(clk), .rst_n(rst_n),
        .hour_tens(hour_tens), .hour_ones(hour_ones),
        .min_tens(min_tens), .min_ones(min_ones),
        .sec_tens(sec_tens), .sec_ones(sec_ones)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0; rst_n = 0; errors = 0;
        $dumpfile("digital_clock_top.vcd");
        $dumpvars(0, tb_digital_clock_top);

        #12; rst_n = 1;
        #1;
        if ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h000000)
            $display("PASS: Reset condition");
        else begin
            $display("FAIL: Reset condition");
            errors = errors + 1;
        end

        wait ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h000001);
        $display("PASS: Seconds increment to 00:00:01");

        wait ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h000100);
        $display("PASS: Minute rollover to 00:01:00");

        wait ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h010000);
        $display("PASS: Hour rollover to 01:00:00");

        wait ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h235959);
        $display("PASS: Clock reached 23:59:59");

        wait ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h000000);
        $display("PASS: Day rollover to 00:00:00");

        if (errors == 0) $display("DIGITAL CLOCK TEST PASSED");
        else $display("DIGITAL CLOCK TEST FAILED");
        $finish;
    end

    initial begin
        #3000000;
        $display("ERROR: Simulation timeout");
        $finish;
    end
endmodule
