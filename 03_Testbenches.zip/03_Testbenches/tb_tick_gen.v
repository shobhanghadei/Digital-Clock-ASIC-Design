`timescale 1ns/1ps
module tb_tick_gen;
    reg clk;
    reg rst_n;
    wire tick_1s;
    integer pulse_count;

    tick_gen #(.CLK_FREQ_HZ(4)) DUT (
        .clk(clk), .rst_n(rst_n), .tick_1s(tick_1s)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 1'b0;
        rst_n = 1'b0;
        pulse_count = 0;
        $dumpfile("tick_gen.vcd");
        $dumpvars(0, tb_tick_gen);

        #12;
        rst_n = 1'b1;
        repeat (12) begin
            @(posedge clk);
            #1;
            if (tick_1s)
                pulse_count = pulse_count + 1;
        end

        if (pulse_count == 3)
            $display("PASS: Tick Generator");
        else
            $display("FAIL: Tick Generator, pulses = %0d", pulse_count);
        $finish;
    end
endmodule
