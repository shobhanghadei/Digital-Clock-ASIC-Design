`timescale 1ns/1ps
module tb_seconds_counter;
    reg clk, rst_n, tick_1s;
    wire [5:0] sec_count;
    wire min_tick;
    integer i;

    seconds_counter DUT (
        .clk(clk), .rst_n(rst_n), .tick_1s(tick_1s),
        .sec_count(sec_count), .min_tick(min_tick)
    );

    always #5 clk = ~clk;

    task send_tick;
    begin
        @(negedge clk);
        tick_1s = 1'b1;
        @(negedge clk);
        tick_1s = 1'b0;
        #1;
    end
    endtask

    initial begin
        clk = 0; rst_n = 0; tick_1s = 0;
        $dumpfile("seconds_counter.vcd");
        $dumpvars(0, tb_seconds_counter);
        #12; rst_n = 1;

        for (i = 0; i < 59; i = i + 1)
            send_tick;

        if (sec_count == 6'd59)
            $display("PASS: Seconds reached 59");
        else
            $display("FAIL: Seconds count incorrect");

        send_tick;
        if (sec_count == 6'd0 && min_tick == 1'b1)
            $display("PASS: Seconds rollover and minute tick");
        else
            $display("FAIL: Seconds rollover");
        $finish;
    end
endmodule
