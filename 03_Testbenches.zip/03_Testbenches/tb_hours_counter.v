`timescale 1ns/1ps
module tb_hours_counter;
    reg clk, rst_n, hour_tick;
    wire [4:0] hour_count;
    integer i;

    hours_counter DUT (
        .clk(clk), .rst_n(rst_n), .hour_tick(hour_tick),
        .hour_count(hour_count)
    );

    always #5 clk = ~clk;

    task send_tick;
    begin
        @(negedge clk);
        hour_tick = 1'b1;
        @(negedge clk);
        hour_tick = 1'b0;
        #1;
    end
    endtask

    initial begin
        clk = 0; rst_n = 0; hour_tick = 0;
        $dumpfile("hours_counter.vcd");
        $dumpvars(0, tb_hours_counter);
        #12; rst_n = 1;

        for (i = 0; i < 23; i = i + 1)
            send_tick;

        if (hour_count == 5'd23)
            $display("PASS: Hours reached 23");
        else
            $display("FAIL: Hours count incorrect");

        send_tick;
        if (hour_count == 5'd0)
            $display("PASS: Hours rollover 23 to 00");
        else
            $display("FAIL: Hours rollover");
        $finish;
    end
endmodule
