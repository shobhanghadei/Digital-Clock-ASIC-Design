`timescale 1ns/1ps
module tb_display_ctrl;
    reg [4:0] hour_count;
    reg [5:0] min_count, sec_count;
    wire [3:0] hour_tens, hour_ones;
    wire [3:0] min_tens, min_ones;
    wire [3:0] sec_tens, sec_ones;

    display_ctrl DUT (
        .hour_count(hour_count), .min_count(min_count), .sec_count(sec_count),
        .hour_tens(hour_tens), .hour_ones(hour_ones),
        .min_tens(min_tens), .min_ones(min_ones),
        .sec_tens(sec_tens), .sec_ones(sec_ones)
    );

    initial begin
        $dumpfile("display_ctrl.vcd");
        $dumpvars(0, tb_display_ctrl);
        hour_count = 0; min_count = 0; sec_count = 0;
        #10;
        if ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h000000)
            $display("PASS: Display 00:00:00");
        else
            $display("FAIL: Display 00:00:00");

        hour_count = 5'd14; min_count = 6'd35; sec_count = 6'd48;
        #10;
        if ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h143548)
            $display("PASS: Display 14:35:48");
        else
            $display("FAIL: Display 14:35:48");

        hour_count = 5'd23; min_count = 6'd59; sec_count = 6'd59;
        #10;
        if ({hour_tens,hour_ones,min_tens,min_ones,sec_tens,sec_ones} == 24'h235959)
            $display("PASS: Display 23:59:59");
        else
            $display("FAIL: Display 23:59:59");
        $finish;
    end
endmodule
